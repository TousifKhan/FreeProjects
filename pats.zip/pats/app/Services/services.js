patsApp.service('Session', function() {
	this.create = function(data) {
		this.id = data.id;
		this.login = data.login;
		this.firstName = data.firstName;
		this.lastName = data.familyName;
		this.email = data.email;
		this.userRoles = [];
		angular.forEach(data.authorities, function(value, key) {
			this.push(value.name);
		}, this.userRoles);
	};
	this.invalidate = function() {
		this.id = null;
		this.login = null;
		this.firstName = null;
		this.lastName = null;
		this.email = null;
		this.userRoles = null;
	};
	return this;
});

patsApp.service('AuthSharedService', function($rootScope, $http, $resource, authService, Session) {
	return {
		login : function(userName, password) {
			/*var config = {
				params : {
					username : userName,
					password : password
				},
				ignoreAuthModule : 'ignoreAuthModule'
			};*/
			var user = {name : userName, password : password};
			$http.post('authenticate', user)
			.success(function(data, status, headers, config) {
				authService.loginConfirmed(data);
			})
			.error(function(data, status, headers, config) {
				$rootScope.authenticationError = true;
				Session.invalidate();
			});
		},
		getAccount : function() {
			$rootScope.loadingAccount = true;
			$http.get('security/account')
			.then(function(response) {
				authService.loginConfirmed(response.data);
			});
		},
		isAuthorized : function(authorizedRoles) {
			if (!angular.isArray(authorizedRoles)) {
				if (authorizedRoles == '*') {
					return true;
				}
				authorizedRoles = [ authorizedRoles ];
			}
			var isAuthorized = false;
			angular.forEach(authorizedRoles, function(authorizedRole) {
				var authorized = (!!Session.login && Session.userRoles.indexOf(authorizedRole) !== -1);
				if (authorized || authorizedRole == '*') {
					isAuthorized = true;
				}
			});
			return isAuthorized;
		},
		logout : function() {
			$rootScope.authenticationError = false;
			$rootScope.authenticated = false;
			$rootScope.account = null;
			$http.get('logout');
			Session.invalidate();
			authService.loginCancelled();
		}
	};
});

patsApp.service('HomeService', function($log, $resource) {
	return {
		getTechno : function() {
			var userResource = $resource('resources/json/techno.json', {}, {
				query : {
					method : 'GET',
					params : {},
					isArray : true
				}
			});
			return userResource.query();
		}
	}
});

patsApp.service('UsersService', function($log, $resource) {
	return {
		getAll : function() {
			var userResource = $resource('users', {}, {
				query : {
					method : 'GET',
					params : {},
					isArray : true
				}
			});
			return userResource.query();
		}
	}
});

patsApp.service('TokensService', function($log, $resource) {
	return {
		getAll : function() {
			var tokensResource = $resource('security/tokens', {}, {
				query : {
					method : 'GET',
					params : {},
					isArray : true
				}
			});
			return tokensResource.query();
		}
	}
});