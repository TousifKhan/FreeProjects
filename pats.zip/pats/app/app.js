var patsApp = angular.module('patsApp', 
	['ui.router', 
	 'patsApp.controllers', 
	 'ajaxLoader', 
	 'http-auth-interceptor', 
	 'ngResource', 
	 'ngExDialog']);

patsApp.constant('USER_ROLES', {
	all		: '*',
	admin	: 'admin',
	user	: 'user'
});

patsApp.config([
    '$stateProvider', '$urlRouterProvider', 'exDialogProvider', function($stateProvider, $urlRouterProvider, exDialogProvider) {
    	exDialogProvider.setDefaults({
            template: '/pats/app/vendor/ngExDialog/commonDialog.html', //from cache
            width: '330px',
            //Below items are set within the provider. Any value set here will overwrite that in the provider.
            //closeByXButton: true,
            //closeByClickOutside: true,
            //closeByEscKey: true,
            //appendToElement: '',
            //beforeCloseCallback: '',
            //grayBackground: true,
            //cacheTemplate: true,
            //draggable: true,
            //animation: true,
            //messageTitle: 'Information',
            //messageIcon: 'info',
            //messageCloseButtonLabel: 'OK',
            //confirmTitle: 'Confirmation',
            //confirmIcon: 'question',
            //confirmActionButtonLabel: 'Yes',
            //confirmCloseButtonLabel: 'No'
        });
    $stateProvider
		.state('base', {
			abstract : true,
			url : '/',
			views : {
				"": {
					templateUrl : '/pats/app/Templates/_tpl.base.html',
				},
				"header@base" : {
					templateUrl : '/pats/app/Views/Common/_header.html',
					controller  : 'HeaderController'//function($scope) {}
				},
				"sidebar@base" 	: {
					templateUrl : '/pats/app/Views/Common/_sidebar.left.html',
					controller 	: function($scope) {}
				},
				"footer@base" 	: {
					templateUrl : '/pats/app/Views/Common/_footer.html',
					controller 	: function($scope) {}
				}
			}
		})
		.state('auth', {
			abstract : true,
			url : '/',
			templateUrl : '/pats/app/Templates/_tpl.auth.html',
		})
		.state('auth.login', {
			url : 'login',
			views: {
				'body@auth': {
					templateUrl: '/pats/app/Views/_login.html',
					controller : 'LoginController'
				}
			}
		})
		.state('base.profile', {
			url : 'profile',
			views: {
				'body@base': {
					templateUrl: '/pats/app/Views/_tpl.profile.html',
					controller : function($scope) {}
				}
			}
		})
		.state('base.dashboard', {
			url : 'dashboard',
			views: {
				'body@base': {
					templateUrl: '/pats/app/Views/Dashboard/_dashboard.html',
					controller : 'DashboardController',
					resolve	: {
						Dashboard : function(){
							return { 
								plans : { name: 'My Plans', size: 2}
							}
						}
					}
				}
			}
		})
		.state('base.plans', {
			url : 'plans',
			views: {
				'body@base': {
					templateUrl	: '/pats/app/Views/Plan/_tpl.plans.html',
					controller 	: 'PlansController'
				}
			}
		})
		.state('base.reports', {
			url : 'reports',
			views: {
				'body@base': {
					templateUrl	: '/pats/app/Views/Action/Report/_tpl.reports.html',
					controller 	: 'ReportsController'
				}
			}
		})
		.state('base.tabs', {
			url : 'tabs',
			views: {
				'body@base': {
					templateUrl: '/pats/app/Views/Pages/_tpl.tabs.html',
					controller : function($scope) {}
				}
			}
		});
		}
    ]);

patsApp.run(
	['$rootScope', '$location', '$http', 'AuthSharedService', 'Session', 'USER_ROLES', '$q', '$timeout', '$state', '$stateParams', 
    function ($rootScope, $location, $http, AuthSharedService, Session, USER_ROLES, $q, $timeout, $state, $stateParams) {
		
		$rootScope.$state = $state;
		$rootScope.$stateParams = $stateParams;
		$state.transitionTo('auth.login');//base.dashboard
		
		$rootScope.$on('$routeChangeStart', function (event, next) {
			if(next.originalPath === "/login" && $rootScope.authenticated) {
				event.preventDefault();
			} 
			else if (next.access && next.access.loginRequired && !$rootScope.authenticated) {
				event.preventDefault();
		        $rootScope.$broadcast("event:auth-loginRequired", {});
			} 
			else if (next.access && !AuthSharedService.isAuthorized(next.access.authorizedRoles)) {
				event.preventDefault();
		        $rootScope.$broadcast("event:auth-forbidden", {});
			}
		});

		$rootScope.$on('$routeChangeSuccess', function (scope, next, current) {
			$rootScope.$evalAsync(function () {
				$.material.init();
			});
		});

		//Call when the the client is confirmed
		$rootScope.$on('event:auth-loginConfirmed', function (event, data) {
		    $rootScope.loadingAccount = false;
		    var nextLocation = ($rootScope.requestedUrl ? $rootScope.requestedUrl : "/dashboard");
		    var delay = ($location.path() === "/dashboard" ? 1500 : 0);

		    $timeout(function () {
		    	Session.create(data);
		        $rootScope.account = Session;
		        $rootScope.authenticated = true;
		        $location.path(nextLocation).replace();
		        }, delay);
		    });

		// Call when the 401 response is returned by the server
		$rootScope.$on('event:auth-loginRequired', function (event, data) {
			if ($rootScope.loadingAccount && data.status !== 401) {
				$rootScope.requestedUrl = $location.path()
		        $location.path('/loading');
			} 
			else {
				Session.invalidate();
		        $rootScope.authenticated = false;
		        $rootScope.loadingAccount = false;
		        $location.path('/login');
		    }
		});

		// Call when the 403 response is returned by the server
		$rootScope.$on('event:auth-forbidden', function (rejection) {
			$rootScope.$evalAsync(function () {
				$location.path('/error/403').replace();
			});
		});

		//Call when the user logs out
		$rootScope.$on('event:auth-loginCancelled', function () {
			$location.path('/login').replace();
		});

		// Get already authenticated user account
		//AuthSharedService.getAccount();

	}]);
