'use strict';
angular.module('patsApp.controllers', ['ui.bootstrap', function () {}])
	.controller('BodyController', ['$scope', '$location', '$state', function ($scope, $location, $state) {
		$scope.body = {};
		$scope.body.dirty = false;
		//Dirty warning when redirecting to any external site either by clicking button or entering site URL.
		window.onbeforeunload = function (event) {
			if ($scope.body.dirty) {
				return "The page will be rediracted to another site but there is unsaved data on this page.";
			}   
		}; 
	}])
	.controller('LoginController', ['$rootScope', '$scope', 'AuthSharedService', '$state', 
	                                function($rootScope, $scope, AuthSharedService, $state) {
		$scope.appName = 'PATS';
		$scope.login = function() {
			//console.log('Login Controller...');
			$rootScope.authenticationError = false;
           // AuthSharedService.login($scope.username,$scope.password);
					$state.go('base.dashboard'); 
		}
	}])
	.controller('HeaderController', ['$scope', 'AuthSharedService', 'exDialog', 
	                                 function($scope, AuthSharedService, exDialog) {
		$scope.openLogOutMsg = function() {
			console.log('in header controller # openLogOutMsg()...');
			exDialog.openConfirm($scope, "Are you sure you wants to Logout?")
			.then(function (value) {
				//$state.go('auth.login');
				AuthSharedService.logout();
			});
		}
	}])
	.controller('DashboardController', ['$scope', '$state', 'Dashboard','exDialog', 
	                                    function($scope, $state, Dashboard, exDialog) {
		$scope.appName = 'PATS Dashboard';
		$scope.plans = Dashboard.plans;
		$scope.openMsg = function() {
			console.log('in DashboardController # openMsg()...');
			exDialog.openMessage($scope, "This is called from a simple line of parameters.", "Warning", "warning");
		}
	}])
	.controller('PlansController', ['$scope', '$state', 'exDialog',
	                                function($scope, $state, exDialog) {
		$scope.moduleName = 'Plans & Edit';
		$scope.description = 'View reports based on category';
		$scope.openMsg = function() {
			console.log('in PlansController # openMsg()...');
			exDialog.openMessage($scope, "This is called from a simple line of parameters.", "Warning", "warning");
		}
	}])
	.controller('ReportsController', ['$scope', '$state', 'exDialog',
	                                function($scope, $state, exDialog) {
		$scope.moduleName = 'Reports';
		$scope.description = 'View reports based on category';
		$scope.openMsg = function() {
			console.log('in PlansController # openMsg()...');
			exDialog.openMessage($scope, "This is called from a simple line of parameters.", "Warning", "warning");
		}
	}])
	
	;
